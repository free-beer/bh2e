# bh2e
A Foundry VTT system definition for the Black Hack 2e RPG.
